CONTRIBUTIONS

Iason: 

Siam:

REPORT

TODO: add your report according to the instructions in the
"Experiments and analysis" section of the assignment description.
